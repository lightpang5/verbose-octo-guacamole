-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: futsal
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `qnaboard_tb`
--

DROP TABLE IF EXISTS `qnaboard_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `qnaboard_tb` (
  `Q_B_NO` int(11) NOT NULL AUTO_INCREMENT,
  `Q_B_NAME` varchar(45) NOT NULL,
  `Q_B_SECRET` varchar(45) NOT NULL,
  `Q_B_SECRETCODE` varchar(45) DEFAULT NULL,
  `Q_B_DATE` datetime NOT NULL,
  `Q_B_READCOUNT` int(11) NOT NULL DEFAULT '0',
  `Q_B_CONTENTS` text NOT NULL,
  `Q_B_TITLE` varchar(45) NOT NULL,
  `ID` varchar(45) NOT NULL,
  PRIMARY KEY (`Q_B_NO`),
  KEY `ID_idx` (`ID`),
  KEY `ID_QNA_idx` (`ID`),
  CONSTRAINT `ID_QNA` FOREIGN KEY (`ID`) REFERENCES `member_tb` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qnaboard_tb`
--

LOCK TABLES `qnaboard_tb` WRITE;
/*!40000 ALTER TABLE `qnaboard_tb` DISABLE KEYS */;
/*!40000 ALTER TABLE `qnaboard_tb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-05 18:13:00
