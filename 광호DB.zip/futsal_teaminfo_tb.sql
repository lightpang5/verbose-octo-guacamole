-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: futsal
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `teaminfo_tb`
--

DROP TABLE IF EXISTS `teaminfo_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `teaminfo_tb` (
  `T_CODE` int(11) NOT NULL,
  `T_NAME` varchar(45) NOT NULL,
  `T_LOGO` varchar(45) DEFAULT NULL,
  `T_RANKING` int(11) DEFAULT NULL,
  `T_UNIFORM_HOME` varchar(45) NOT NULL,
  `T_UNIFORM_AWAY` varchar(45) NOT NULL,
  `T_BIRTH` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `T_CLASS` varchar(45) NOT NULL,
  `LEAGUE_RESULT_CODE` int(11) DEFAULT NULL,
  `ID` varchar(45) NOT NULL,
  `T_EMAIL` varchar(45) NOT NULL,
  PRIMARY KEY (`T_CODE`),
  KEY `teaminfo_member_id_idx` (`ID`),
  CONSTRAINT `teaminfo_member_id` FOREIGN KEY (`ID`) REFERENCES `member_tb` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaminfo_tb`
--

LOCK TABLES `teaminfo_tb` WRITE;
/*!40000 ALTER TABLE `teaminfo_tb` DISABLE KEYS */;
INSERT INTO `teaminfo_tb` VALUES (1111,'축잘알','aston.png',1,'상의 - red 하의 - red 스타킹 - red','상의 - blue 하의 - blue 스타킹 - blue','2020-02-11 13:12:36','성인부',1,'aaaaaa','mailmail@naver.com'),(562521,'축알못','arsenal.png',NULL,'상의 - white 하의 - white 스타킹 - white','상의 - red 하의 - red 스타킹 - blue','2020-02-17 19:58:30','초등부',NULL,'aaaaaa','mailmial@naver.commm');
/*!40000 ALTER TABLE `teaminfo_tb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-27 16:01:32
