-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: futsal
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_tb`
--

DROP TABLE IF EXISTS `member_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `member_tb` (
  `ID` varchar(45) NOT NULL,
  `NAME` varchar(45) NOT NULL,
  `PW` varchar(45) NOT NULL,
  `TEL` varchar(45) NOT NULL,
  `EMAIL` varchar(45) NOT NULL,
  `GENDER` varchar(45) NOT NULL,
  `ADDRESS_CODE` varchar(45) NOT NULL,
  `ADDRESS_BASIC` varchar(100) DEFAULT NULL,
  `ADDRESS_DETAIL` varchar(100) DEFAULT NULL,
  `BIRTH` varchar(45) DEFAULT NULL,
  `PIC` varchar(45) DEFAULT NULL,
  `LEVEL` varchar(45) DEFAULT NULL,
  `POSITION` varchar(45) DEFAULT NULL,
  `SECOND_PW` varchar(45) DEFAULT NULL,
  `SECOND_PWC` varchar(45) DEFAULT NULL,
  `BANK_CODE` varchar(45) DEFAULT NULL,
  `ACCOUNT_CODE` varchar(45) DEFAULT NULL,
  `ACCOUNT_HOLDER` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_tb`
--

LOCK TABLES `member_tb` WRITE;
/*!40000 ALTER TABLE `member_tb` DISABLE KEYS */;
INSERT INTO `member_tb` VALUES ('aaaaaa','김팡호','123123','010-1234-1234','aaaaaa123@naver.com','male','08789','서울 관악구 낙성대로 2','없음','1995년 08월 03일','liverpool.jpg','5','FW ','Q02','얍얍얍','001','123123123','김팡호'),('aaaaaaaa','팡호킴','123123','010-1234-5678','email@naver.com','female','08742','서울 관악구 남부순환로241길 11','','1995년 08월 14일','dd.jpg','5','FW MF ','Q02','바르게 살자','001','1122334455','김팡호'),('asdfasdf','김강강','123123','010-1231-1231','ddddddddddd@naver.com','female','06313','서울 강남구 양재대로 333','','1920년 01월 01일','','5','','Q01','','001','123123','김강강');
/*!40000 ALTER TABLE `member_tb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-21 18:14:27
